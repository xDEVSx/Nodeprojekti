const http = require('http');

// Luo serverin objekti
http.createServer((req, res) => {
    // Kirjoita vastaus
    res.write('Terve vuoon');
    res.end();
})
    .listen(2525, () => console.log('Serveri päällä!!...'));