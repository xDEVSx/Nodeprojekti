const os = require('os')

// Alusta
console.log(os.platform());

// CPU Arch
console.log(os.arch());

// CPU Core Info
console.log(os.cpus());

// Vapaa Muisti
console.log(os.freemem());

// Yhteis Muisti
console.log(os.totalmem())

// Koti kansio
console.log(os.homedir());

// Uptime
console.log(os.uptime());