const url = require('url')

const myUrl = new URL('http://omasivu.fi/terve.html?id=100&status=active');

// Serialized URL
console.log(myUrl.href);

// Host (Root domaini)
console.log(myUrl.host);

// Hostname
console.log(myUrl.hostname);

// Pathname
console.log(myUrl.pathname);

// Serialized query
console.log(myUrl.search);

// Params Obj
console.log(myUrl.searchParams);

// Add param
myUrl.searchParams.append('abc', '123');
console.log(myUrl.searchParams);

// Looppi
myUrl.searchParams.forEach((value, name) => console.log(`${name}: ${value}`));