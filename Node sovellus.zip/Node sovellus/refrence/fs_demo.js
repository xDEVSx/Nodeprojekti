const fs = require('fs');
const path = require('path');

// Luo kansio
//fs.mkdir(path.join(__dirname, '/testi'), {}, err => {
   // if(err) throw err;
    //console.log('Kansio luotu...');
//});

// Luo ja tee tiedosto
//fs.writeFile(path.join(__dirname, '/testi', 'terve.txt'), 'Juu', err => {
    //if(err) throw err;
   // console.log('Tiedosto luotu...');
//});

// Append File
//fs.appendFile(path.join(__dirname, '/testi', 'terve.txt'), 'Vihaan Nodea', err => {
    //if(err) throw err;
    //console.log('Tiedosto luotu...');
//});

//Lue tiedosto
//fs.readFile(path.join(__dirname, '/testi', 'terve.txt'), 'utf8', (err, data) => {
   // if(err) throw err;
   // console.log(data);
//});

// Uudelleen nimeä tiedosto
fs.rename(path.join(__dirname, '/testi', 'terve.txt'), path.join(__dirname, '/testi', 'terveee.txt'), (err, data) => {
    if(err) throw err;
    console.log('Tiedosto uudelleennimetty...');
    }
);
